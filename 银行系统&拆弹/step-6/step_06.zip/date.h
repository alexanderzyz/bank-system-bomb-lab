#ifndef _A_
#define _A_
#include<iostream>
#include<stack>
#include <sstream>
using namespace std;
class Date
{
    public:
    int year,month,day;
    Date();
    Date(int y,int m,int d);
    void show();
    static Date read();
    int getDay();
    int getYear();
    int getMonth();
    int getMaxDay();
};
#endif